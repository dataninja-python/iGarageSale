#!/bin/bash

npm i express ejs dotenv emethod-override mongoose
npm i jshint
npm i --save-dev @types/node