/*
* dependencies
* */
// object relational mapper to connect mongo db and nodejs
var mongoose = require("mongoose");
var bcrypt = require("bcrypt");
var Schema = mongoose.Schema;
/*
* create schema
* */
// user blueprint
var UserSchema = new Schema({
    email: { type: String, unique: true, lowercase: true },
    password: String,
    profile: {
        name: { type: String, "default": "" },
        picture: { type: String, "default": "" }
    },
    address: String,
    history: [{
            date: Date,
            paid: { type: Number, "default": 0 }
        }]
});
/*
* hash password
* */
// hash password before saving to db for better security
// inserted as is from course to prevent mysterious promise error caused by ES6 updates
// UserSchema.pre('save', function(next) {
//     const user = this;
//     if (!user.isModified('password')) return next();
//     bcrypt.genSalt(10, function(err, salt) {
//         if (err) return next(err);
//         bcrypt.hash(user.password, salt, null, function(err, hash) {
//             if (err) return next(err);
//             user.password = hash;
//             // next();
//             // attempted fix to hanging
//             return next();
//         });
//     });
// });
/*
* password comparison
* */
// create a custom method to compare user and db passwords
UserSchema.methods.comparePassword = function (password) {
    return bcrypt.compareSync(password, this.password);
};
/*
* export
* */
var User = mongoose.model("User", UserSchema);
module.exports = User;
